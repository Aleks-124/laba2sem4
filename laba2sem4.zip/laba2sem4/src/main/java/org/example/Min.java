package org.example;
import org.apache.commons.math3.stat.StatUtils;
import java.util.HashMap;

public class Min {
    private  double[] dataarray;
    private HashMap<String, Double> dictionary;
    public static HashMap<String, Double> Min(HashMap<String, Double> dictionary,double[] dataarray) {
        dictionary.put("минимум", StatUtils.min(dataarray));
        return dictionary;
    }
}
