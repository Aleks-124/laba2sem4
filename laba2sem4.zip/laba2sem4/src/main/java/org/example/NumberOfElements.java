package org.example;
import org.apache.commons.math3.stat.StatUtils;
import java.util.HashMap;

public class NumberOfElements {
    private  double[] dataarray;
    private HashMap<String, Double> dictionary;
    public static HashMap<String, Double> NumberOfElements(HashMap<String, Double> dictionary,double[] dataarray) {
        dictionary.put("кол-во элементов", Double.valueOf(dataarray.length));
        return dictionary;
    }
}
