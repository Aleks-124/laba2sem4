package org.example;

import org.apache.poi.ss.usermodel.*;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;

public class ExportModule {
    public static void writeExcelFile(HashMap<String, Double>[] data) {
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Data");

            Row headerRow = sheet.createRow(0);

            int cellNum = 0;
            for (String key : data[0].keySet()) {
                Cell cell = headerRow.createCell(cellNum++);
                cell.setCellValue(key);
            }

            for (int i = 0; i < data.length; i++) {
                Row row = sheet.createRow(i + 1);

                int cellNumData = 0;
                for (Double value : data[i].values()) {
                    Cell cell = row.createCell(cellNumData++);
                    cell.setCellValue(value);
                }
            }

            FileOutputStream fileOut = new FileOutputStream("output.xlsx");
            workbook.write(fileOut);
            fileOut.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
