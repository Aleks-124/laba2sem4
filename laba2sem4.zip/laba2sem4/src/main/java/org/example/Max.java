package org.example;
import org.apache.commons.math3.stat.StatUtils;
import java.util.HashMap;

public class Max {
    private  double[] dataarray;
    private HashMap<String, Double> dictionary;
    public static HashMap<String, Double> Max(HashMap<String, Double> dictionary,double[] dataarray) {
        dictionary.put("максимум", StatUtils.max(dataarray));
        return dictionary;
    }
}
