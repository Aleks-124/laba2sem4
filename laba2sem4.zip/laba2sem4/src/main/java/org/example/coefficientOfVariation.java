package org.example;
import org.apache.commons.math3.stat.StatUtils;
import java.util.HashMap;

public class coefficientOfVariation {
    private  double[] dataarray;
    private HashMap<String, Double> dictionary;
    public static HashMap<String, Double> coefficientOfVariation(HashMap<String, Double> dictionary,double[] dataarray) {
        dictionary.put("коэф вариации", Math.sqrt(StatUtils.variance(dataarray))/StatUtils.mean(dataarray));
        return dictionary;
    }
}
