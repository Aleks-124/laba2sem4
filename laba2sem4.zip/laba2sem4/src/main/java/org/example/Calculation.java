package org.example;
import org.apache.commons.math3.stat.StatUtils;
import java.util.HashMap;

public class Calculation {
    private  double[] dataarray;
    private HashMap<String, Double> dictionary;
    public static void Calculation(HashMap<String, Double> dictionary,double[] dataarray) {
        ArithmeticMean.ArithmeticMean(dictionary,dataarray);
        coefficientOfVariation.coefficientOfVariation(dictionary,dataarray);
        GeometricMeanCalculator.geometricMeanCalculator(dictionary,dataarray);
        Max.Max(dictionary,dataarray);
        Min.Min(dictionary,dataarray);
        NumberOfElements.NumberOfElements(dictionary,dataarray);
        SampleSpan.SampleSpan(dictionary,dataarray);
        StandarDeviation.StandarDeviation(dictionary,dataarray);
        Variance.Variance(dictionary,dataarray);
    }
}
