package org.example;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;

import org.apache.poi.ss.usermodel.*;

public class Main {
    private static JTextField textField;

    public static void main(String[] args) {
        JFrame frame = new JFrame("Excel Data Importer");
        frame.setSize(400, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        textField = new JTextField();
        textField.setBounds(100, 100, 200, 30);

        JButton importButton = new JButton("Import Excel File");
        importButton.setBounds(100, 50, 200, 30);

        importButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setCurrentDirectory(new File(System.getProperty("user.home") + "/Desktop"));
                int result = fileChooser.showOpenDialog(null);

                if (result == JFileChooser.APPROVE_OPTION) {
                    File file = fileChooser.getSelectedFile();
                    try {
                        FileInputStream fis = new FileInputStream(file);
                        Workbook workbook = WorkbookFactory.create(fis);
                        int sheetNumber = Integer.parseInt(textField.getText());
                        Sheet selectedSheet = workbook.getSheetAt(sheetNumber - 1);
                        double[][] xyzArray = InputModule.InputModule(sheetNumber,selectedSheet);
                        HashMap<String, Double> xmap = new HashMap<>();
                        HashMap<String, Double> ymap = new HashMap<>();
                        HashMap<String, Double> zmap = new HashMap<>();
                        Calculation.Calculation(xmap,xyzArray[0]);
                        Calculation.Calculation(ymap,xyzArray[0]);
                        Calculation.Calculation(zmap,xyzArray[0]);
                         HashMap<String, Double>[] mapArray = new HashMap[3];
                        mapArray[0] = xmap;
                        mapArray[1] = ymap;
                        mapArray[2] = zmap;
                        ExportModule.writeExcelFile(mapArray);
                    } catch (Exception ex) {
                        ex.printStackTrace();
                        System.out.println("Ошибка при импорте и чтении данных из файла Excel.");
                        String errorMessage = "Ошибка при импорте и чтении данных из файла Excel";

                        // Отображение информационного сообщения
                        JOptionPane.showMessageDialog(null, errorMessage, "Ошибка", JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            }
        });

        frame.add(textField);
        frame.add(importButton);
        frame.setLayout(null);
        frame.setVisible(true);
    }
}
