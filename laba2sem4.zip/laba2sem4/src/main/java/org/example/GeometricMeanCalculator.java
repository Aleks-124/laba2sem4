package org.example;
import org.apache.commons.math3.stat.StatUtils;
import java.util.HashMap;

public class GeometricMeanCalculator {
    private  double[] dataarray;
    private HashMap<String, Double> dictionary;

    public static HashMap<String, Double> geometricMeanCalculator(HashMap<String, Double> dictionary,double[] dataarray) {
        double product = 1.0;
        for (Double str : dataarray) {
            product *= str;
        }

        // Вычисление среднего геометрического
        double geometricMean = Math.pow(product, 1.0 / dataarray.length);
        dictionary.put("Среднее геометрическое", geometricMean);
        return dictionary;
    }
}
