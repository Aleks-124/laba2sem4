package org.example;
import org.apache.commons.math3.stat.StatUtils;
import java.util.HashMap;

public class Variance {
    private  double[] dataarray;
    private HashMap<String, Double> dictionary;
    public static HashMap<String, Double> Variance(HashMap<String, Double> dictionary,double[] dataarray) {
        dictionary.put("дисперсия", StatUtils.variance(dataarray));
        return dictionary;
    }
}
