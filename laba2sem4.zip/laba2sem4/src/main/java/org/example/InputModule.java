package org.example;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;

public class InputModule {
    public static double[][]  InputModule(int sheetNumber, Sheet selectedSheet){
        int numRows = selectedSheet.getPhysicalNumberOfRows();
        int numCols = selectedSheet.getRow(0).getPhysicalNumberOfCells();

        String[] column1 = new String[numRows - 1];
        String[] column2 = new String[numRows - 1];
        String[] column3 = new String[numRows - 1];

        // Считывание данных со второй строки каждого столбца в отдельные массивы
        for (int rowIdx = 1; rowIdx < numRows; rowIdx++) {
            Row row = selectedSheet.getRow(rowIdx);
            column1[rowIdx - 1] = row.getCell(0).toString();
            column2[rowIdx - 1] = row.getCell(1).toString();
            column3[rowIdx - 1] = row.getCell(2).toString();
        }
        double[] column11 = new double[numRows - 1];
        double[] column22 = new double[numRows - 1];
        double[] column33 = new double[numRows - 1];
        for (int i = 0; i < column1.length; i++) {
            column11[i] = Double.parseDouble(column1[i]);
            column22[i] = Double.parseDouble(column2[i]);
            column33[i] = Double.parseDouble(column3[i]);
        }
        double[][] arrayItog = {column11,column22,column33};
        return arrayItog;
    }
}
